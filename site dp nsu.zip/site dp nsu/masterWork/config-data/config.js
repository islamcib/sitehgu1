module.exports = {
    connectArray:{
        host: 'localhost',
        dialect:'mysql',
        database:'master_work',
        prefix:'msrw_',
        user_name:'root',
        password:''

    }
};